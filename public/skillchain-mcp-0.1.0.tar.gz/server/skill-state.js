/**
 * Skill State Store — persistent per-skill state, run tracking, and history.
 * Port of sdk/skill_state.py
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync } from "fs";
import { join } from "path";
import { homedir } from "os";
function sanitizeName(name) {
    let safe = name.replace(/[/\\]/g, "").replace(/\0/g, "");
    while (safe.includes(".."))
        safe = safe.replace("..", "");
    safe = safe.replace(/^\.+/, "");
    return safe || "unknown";
}
export class SkillStateStore {
    baseDir;
    constructor(baseDir) {
        this.baseDir = baseDir ?? join(homedir(), ".skillchain", "state");
        mkdirSync(this.baseDir, { recursive: true });
    }
    skillDir(skillName) {
        const safe = sanitizeName(skillName);
        const dir = join(this.baseDir, safe);
        mkdirSync(dir, { recursive: true });
        return dir;
    }
    getState(skillName) {
        const dir = this.skillDir(skillName);
        const statePath = join(dir, "state.json");
        if (existsSync(statePath)) {
            try {
                return JSON.parse(readFileSync(statePath, "utf-8"));
            }
            catch {
                // corrupted, return default
            }
        }
        return {
            skill_name: skillName,
            last_run: null,
            accumulated_data: {},
            run_count: 0,
            first_run: "",
            last_run_at: "",
        };
    }
    saveState(skillName, state) {
        const dir = this.skillDir(skillName);
        writeFileSync(join(dir, "state.json"), JSON.stringify(state, null, 2), "utf-8");
    }
    startRun(skillName, executionPattern = "orpa", metadata = {}) {
        return {
            skill_name: skillName,
            execution_pattern: executionPattern,
            started_at: new Date().toISOString(),
            completed_at: "",
            status: "in_progress",
            phases: [],
            metadata,
        };
    }
    recordPhase(run, phase, status, output = {}, durationMs = 0) {
        const result = {
            phase,
            status,
            output,
            timestamp: new Date().toISOString(),
            duration_ms: durationMs,
        };
        run.phases.push(result);
        return result;
    }
    completeRun(run, status = "completed") {
        run.completed_at = new Date().toISOString();
        run.status = status;
        const state = this.getState(run.skill_name);
        state.last_run = run;
        state.run_count += 1;
        state.last_run_at = run.completed_at;
        if (!state.first_run)
            state.first_run = run.started_at;
        this.saveState(run.skill_name, state);
        // Archive to history
        const histDir = join(this.skillDir(run.skill_name), "history");
        mkdirSync(histDir, { recursive: true });
        const ts = run.completed_at.replace(/[:.]/g, "-");
        writeFileSync(join(histDir, `${ts}.json`), JSON.stringify(run, null, 2), "utf-8");
    }
    saveData(skillName, key, data) {
        const dir = this.skillDir(skillName);
        const safeKey = sanitizeName(key);
        writeFileSync(join(dir, `data_${safeKey}.json`), JSON.stringify(data, null, 2), "utf-8");
        const state = this.getState(skillName);
        state.accumulated_data[key] = data;
        this.saveState(skillName, state);
    }
    loadData(skillName, key) {
        const dir = this.skillDir(skillName);
        const safeKey = sanitizeName(key);
        const path = join(dir, `data_${safeKey}.json`);
        if (existsSync(path)) {
            try {
                return JSON.parse(readFileSync(path, "utf-8"));
            }
            catch {
                return null;
            }
        }
        return null;
    }
    getRunHistory(skillName, limit = 10) {
        const histDir = join(this.skillDir(skillName), "history");
        if (!existsSync(histDir))
            return [];
        const files = readdirSync(histDir).filter(f => f.endsWith(".json")).sort().reverse().slice(0, limit);
        return files.map(f => {
            try {
                return JSON.parse(readFileSync(join(histDir, f), "utf-8"));
            }
            catch {
                return {};
            }
        });
    }
    listSkillsWithState() {
        if (!existsSync(this.baseDir))
            return [];
        return readdirSync(this.baseDir).filter(d => {
            return existsSync(join(this.baseDir, d, "state.json"));
        });
    }
}
